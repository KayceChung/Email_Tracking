#!/usr/bin/env python3
"""
Gmail Email Logger - Tối ưu hóa lấy dữ liệu từ Gmail và ghi vào Google Sheets
Thay thế 3 script Google Apps Script hiện tại
"""

import os
import pickle
import re
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Set
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.oauth2.service_account import Credentials as ServiceAccountCredentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import gspread
from gspread.auth import authorize
import time

# ==================== CẤU HÌNH ====================
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/spreadsheets'
]

SPREADSHEET_ID = "10DpSr-N4jOU5lhNp-8m0F_0KH5iIKBuTlsAZ3wOtNq0"
SHEETS_CONFIG = {
    "booking": {"name": "EMAIL_BOOKING", "labels": ["KLOOK_BOOKING", "12GO_BOOKING", "BAOLAU_BOOKING"]},
    "confirmed": {"name": "EMAIL_XÁC_NHẬN", "labels": ["KLOOK_CONFIRMED", "12GO_CONFIRMED", "BAOLAU_CONFIRMED"]},
    "cancel": {"name": "EMAIL_HỦY", "labels": ["KLOOK_CONFIRMED_CANCEL", "KLOOK_UNCONFIRMED_CANCEL", "BAOLAU_CANCEL", "12GO_CANCEL"]},
    "ctrip": {"name": "EMAIL_CTRIP", "labels": ["CTRIP", "CTRIP CANCEL"]},
    "seatOS": {"name": "EMAIL_SEATOS", "labels": ["SeatOS-Booking", "SeatOS-Pending", "SeatOS - Unchecked"]},
    "review": {"name": "EMAIL_REVIEW", "labels": ["KLOOK REVIEW", "12GO_REVIEW"]},
    "klook_special": {"name": "EMAIL_KLOOK_SPECIAL", "labels": ["Klook Độc Quyền"]}
}

# ==================== GMAIL AUTHENTICATION ====================
def authenticate_gmail():
    """Xác thực Gmail API"""
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    
    return build('gmail', 'v1', credentials=creds)

def authenticate_gspread():
    """Xác thực Google Sheets"""
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    
    return authorize(creds)

# ==================== LẤY DỮ LIỆU EMAIL ====================
def decode_email_body(payload: Dict) -> str:
    """Giải mã nội dung email từ payload"""
    try:
        def decode_part(part):
            if part.get('body', {}).get('data'):
                import base64
                data = part['body']['data']
                # Thay thế ký tự đặc biệt trong base64
                data = data.replace('-', '+').replace('_', '/')
                decoded = base64.urlsafe_b64decode(data)
                return decoded.decode('utf-8', errors='ignore')
            return ''
        
        # Tìm plain text trước
        parts = payload.get('parts', [])
        for part in parts:
            if part.get('mimeType') == 'text/plain':
                return decode_part(part)
        
        # Nếu không có plain text, tìm HTML
        for part in parts:
            if part.get('mimeType') == 'text/html':
                return decode_part(part)
        
        return payload.get('snippet', '')
    except Exception as e:
        print(f"Error decoding email: {e}")
        return payload.get('snippet', '')

def get_gmail_messages(service, labels: List[str], hours_back: int = 48) -> List[Dict]:
    """Lấy danh sách email từ Gmail với các label cụ thể"""
    all_messages = []
    
    for label in labels:
        try:
            # Tìm label ID
            results = service.users().labels().list(userId='me').execute()
            label_id = None
            for lbl in results.get('labels', []):
                if lbl['name'] == label:
                    label_id = lbl['id']
                    break
            
            if not label_id:
                print(f"⚠️ Label '{label}' không tìm thấy")
                continue
            
            # Lấy email từ label
            query = f"label:{label_id} newer_than:{hours_back}h -in:draft"
            results = service.users().messages().list(
                userId='me',
                q=query,
                maxResults=20
            ).execute()
            
            messages = results.get('messages', [])
            print(f"✓ Tìm thấy {len(messages)} email từ label '{label}'")
            
            for msg in messages:
                msg_detail = service.users().messages().get(
                    userId='me',
                    id=msg['id'],
                    format='full'
                ).execute()
                
                all_messages.append({
                    'label': label,
                    'id': msg['id'],
                    'threadId': msg_detail['threadId'],
                    'payload': msg_detail['payload'],
                    'internalDate': int(msg_detail['internalDate'])
                })
                
                # Rate limiting
                time.sleep(0.1)
        
        except Exception as e:
            print(f"❌ Lỗi xử lý label '{label}': {e}")
    
    return all_messages

# ==================== TRÍCH XUẤT DỮ LIỆU ====================
def extract_order_id(label: str, subject: str, body: str = "") -> str:
    """Trích xuất Order ID theo từng loại label"""
    patterns = {
        "KLOOK": r"-\s([A-Z0-9]+)$",
        "12GO": r"12GO\s*([\w-]+)",
        "BAOLAU": r"\((.*?)\)",
        "CTRIP": r"(?:CTRIP|booking)\s*([\w-]+)",
        "SEATIOS": r"(?:SeatOS|booking)\s*([\w-]+)"
    }
    
    search_text = f"{subject} {body}"
    
    for key, pattern in patterns.items():
        if key.lower() in label.lower():
            match = re.search(pattern, subject, re.IGNORECASE)
            if match:
                return match.group(1)
    
    return "N/A"

def extract_route_points(label: str, subject: str, body: str = "") -> Tuple[str, str]:
    """Trích xuất điểm đón/trả theo từng loại label"""
    
    if "12GO" in label.upper():
        # Format: location1 - location2
        parts = re.search(r"-\s*#12GO\d+\s*(.*)$", subject, re.IGNORECASE)
        if parts and parts.group(1):
            info = parts.group(1).strip()
            # Bỏ ngày/giờ
            cleaned = re.sub(r'^\d{1,2}\s+\w+\s+\d{1,2}:\d{2}\s+\w+\s+', '', info)
            
            # Tìm "Hostel" làm điểm ngăn cách
            idx = cleaned.find("Hostel")
            if idx != -1:
                return (cleaned[:idx].strip(), cleaned[idx:].strip())
            
            # Nếu không, chia đôi
            words = cleaned.split()
            if len(words) >= 2:
                return (' '.join(words[:-2]), ' '.join(words[-2:]))
        
        return ("N/A", "N/A")
    
    if "KLOOK" in label.upper():
        # KLOOK: tìm "Pick-up location" và "Drop-off location"
        pickup_match = re.search(r"Pick-up location:\s*(.*?)(?:\n|Drop-off)", body, re.IGNORECASE)
        dropoff_match = re.search(r"Drop-off location:\s*(.*?)(?:\n|$)", body, re.IGNORECASE)
        
        pickup = pickup_match.group(1).strip() if pickup_match else "N/A"
        dropoff = dropoff_match.group(1).strip() if dropoff_match else "N/A"
        
        return (pickup, dropoff)
    
    return ("N/A", "N/A")

def extract_headers(payload: Dict, header_names: List[str]) -> Dict[str, str]:
    """Trích xuất các header cụ thể từ email"""
    headers = payload.get('headers', [])
    result = {}
    
    for header in headers:
        if header['name'] in header_names:
            result[header['name']] = header['value']
    
    return result

# ==================== GHI VÀO GOOGLE SHEETS ====================
def get_existing_thread_links(worksheet) -> Set[str]:
    """Lấy tất cả thread link đã tồn tại để tránh trùng lặp"""
    try:
        all_values = worksheet.get_all_values()
        if len(all_values) > 1:
            # Cột E (index 4) chứa thread link
            return set(row[4] if len(row) > 4 else "" for row in all_values[1:])
    except:
        pass
    return set()

def format_datetime(timestamp_ms: int) -> Tuple[str, int, str]:
    """Định dạng datetime từ Gmail internalDate"""
    dt = datetime.fromtimestamp(timestamp_ms / 1000)
    formatted = dt.strftime("%Y-%m-%d %H:%M:%S")
    
    # Tính tuần trong năm
    year_start = datetime(dt.year, 1, 1)
    week_num = ((dt - year_start).days // 7) + 1
    
    date_type = dt.strftime("%Y-%m-%d")
    
    return formatted, week_num, date_type

def append_to_sheet(worksheet, rows: List[List], sheet_type: str):
    """Ghi nhiều dòng vào sheet"""
    if not rows:
        print(f"  ⓘ Không có dữ liệu mới cho {sheet_type}")
        return
    
    try:
        worksheet.append_rows(rows)
        print(f"  ✓ Đã ghi {len(rows)} dòng vào {sheet_type}")
    except Exception as e:
        print(f"  ❌ Lỗi ghi sheet: {e}")

# ==================== MAIN FUNCTION ====================
def main():
    """Hàm chính"""
    print("🚀 Bắt đầu lấy dữ liệu email từ Gmail...\n")
    
    # Xác thực
    try:
        gmail_service = authenticate_gmail()
        gs = authenticate_gspread()
        spreadsheet = gs.open_by_key(SPREADSHEET_ID)
        print("✓ Xác thực thành công\n")
    except Exception as e:
        print(f"❌ Lỗi xác thực: {e}")
        return
    
    # Xử lý từng loại sheet
    for sheet_type, config in SHEETS_CONFIG.items():
        print(f"\n📋 Xử lý {sheet_type.upper()}:")
        print(f"   Sheet: {config['name']}")
        print(f"   Labels: {', '.join(config['labels'])}")
        
        try:
            worksheet = spreadsheet.worksheet(config['name'])
        except Exception as e:
            print(f"  ❌ Sheet '{config['name']}' không tìm thấy: {e}")
            continue
        
        # Lấy các thread link đã tồn tại
        existing_links = get_existing_thread_links(worksheet)
        
        # Lấy email
        messages = get_gmail_messages(gmail_service, config['labels'], hours_back=48)
        
        if not messages:
            print(f"  ⓘ Không tìm thấy email mới")
            continue
        
        # Xử lý và chuẩn bị dữ liệu
        rows_to_append = []
        
        for msg in messages:
            thread_link = f"https://mail.google.com/mail/u/0/#inbox/{msg['threadId']}"
            
            # Bỏ qua nếu đã tồn tại
            if thread_link in existing_links:
                continue
            
            # Trích xuất headers
            headers = extract_headers(msg['payload'], ['Subject', 'In-Reply-To', 'References'])
            
            # Bỏ qua email reply
            if 'In-Reply-To' in headers or 'References' in headers:
                continue
            
            subject = headers.get('Subject', 'No Subject')
            body = decode_email_body(msg['payload'])
            
            # Trích xuất dữ liệu
            order_id = extract_order_id(msg['label'], subject, body)
            pickup, dropoff = extract_route_points(msg['label'], subject, body)
            formatted_date, week_num, date_type = format_datetime(msg['internalDate'])
            
            # Chuẩn bị dòng (tùy thuộc vào sheet type)
            if sheet_type == "booking":
                row = [
                    msg['label'],
                    "EMAIL",
                    subject,
                    body[:500],  # Giới hạn body
                    thread_link,
                    formatted_date,
                    week_num,
                    date_type,
                    order_id,
                    "", "", "", "", "", "", "", "", "", "", "",  # J-U
                    pickup,
                    dropoff
                ]
            else:
                row = [
                    msg['label'],
                    "",
                    subject,
                    body[:500],
                    thread_link,
                    formatted_date,
                    week_num,
                    date_type,
                    order_id,
                    "", "", "", "", "", "", ""
                ]
            
            rows_to_append.append(row)
            existing_links.add(thread_link)
        
        # Ghi vào sheet
        append_to_sheet(worksheet, rows_to_append, config['name'])
    
    print("\n✅ Hoàn thành!")

if __name__ == "__main__":
    main()
